
extend.chains <- function(...)
{

}

check.merge <- function(...)
{

}
